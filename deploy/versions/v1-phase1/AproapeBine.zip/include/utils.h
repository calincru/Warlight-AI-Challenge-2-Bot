// This program is free software licenced under MIT Licence. You can
// find a copy of this licence in LICENCE.txt in the top directory of
// source code.
//


#ifndef UTILS_H_INCLUDED
#define UTILS_H_INCLUDED

#define UNUSED(a) (void)(&a)

#endif // UTILS_H_INCLUDED
